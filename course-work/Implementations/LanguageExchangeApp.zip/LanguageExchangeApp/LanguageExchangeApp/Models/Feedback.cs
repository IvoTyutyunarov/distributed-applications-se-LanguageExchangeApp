﻿using System.ComponentModel.DataAnnotations;

namespace LanguageExchangeApp.Models
{
    public class Feedback
    {
        public int Id { get; set; }

        [Required]
        public int SessionId { get; set; }
        public Session Session { get; set; }

        [Required, MaxLength(500)]
        public string Comment { get; set; }

        [Range(1, 5)]
        public int Rating { get; set; }

        public DateTime SubmittedAt { get; set; }
    }

}
