﻿using System.ComponentModel.DataAnnotations;

namespace LanguageExchangeApp.Models
{
    public class Session
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string Topic { get; set; }

        public DateTime ScheduledAt { get; set; }
        public int DurationMinutes { get; set; }

        [Required]
        public int UserId { get; set; }
        public User User { get; set; }

        [Required]
        public int PartnerId { get; set; }
        public User Partner { get; set; }

        public ICollection<Feedback> Feedbacks { get; set; }
    }
}
