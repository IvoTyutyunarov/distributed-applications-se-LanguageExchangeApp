﻿using LanguageExchangeApp.Models;
using LanguageExchangeApp.Data;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LanguageExchangeApp
{
    public static class DataSeeder
    {
        public static void Seed(ApplicationDbContext context)
        {
            if (context.Users.Any()) return;

            var rnd = new Random();
            var hasher = new PasswordHasher<User>();

            var nativeLanguages = new[] { "Bulgarian", "English", "Spanish", "German", "French", "Italian", "Japanese", "Arabic" };
            var targetLanguages = new[] { "English", "Bulgarian", "Spanish", "French", "German", "Portuguese", "Russian", "Mandarin" };
            var topics = new[] { "Travel", "Culture", "Food", "Technology", "Education", "Movies", "Music", "Sports", "Business" };

            // USERS
            var users = new List<User>();
            for (int i = 1; i <= 12; i++)
            {
                var native = nativeLanguages[rnd.Next(nativeLanguages.Length)];
                string learn = targetLanguages[rnd.Next(targetLanguages.Length)];

                var user = new User
                {
                    FullName = $"User {i} {native}",
                    Email = $"user{i}@mail.com",
                    NativeLanguage = native,
                    LanguageToLearn = learn,
                    CreatedAt = DateTime.UtcNow.AddDays(-rnd.Next(300))
                };

                user.Password = hasher.HashPassword(user, "Password123*");

                users.Add(user);
            }

            context.Users.AddRange(users);
            context.SaveChanges();

            // SESSIONS
            var sessions = new List<Session>();
            for (int i = 0; i < 15; i++)
            {
                var user1 = users[rnd.Next(users.Count)];
                User user2 = users[rnd.Next(users.Count)];

                sessions.Add(new Session
                {
                    UserId = user1.Id,
                    PartnerId = user2.Id,
                    ScheduledAt = DateTime.UtcNow.AddDays(-rnd.Next(60)),
                    Topic = topics[rnd.Next(topics.Length)],
                    DurationMinutes = rnd.Next(25, 91)
                });
            }

            context.Sessions.AddRange(sessions);
            context.SaveChanges();

            // FEEDBACKS
            var feedbacks = new List<Feedback>();
            foreach (var session in sessions.OrderBy(x => rnd.Next()).Take(15))
            {
                for (int i = 0; i < 10; i++)
                {
                    feedbacks.Add(new Feedback
                    {
                        SessionId = session.Id,
                        Rating = rnd.Next(1, 5),
                        Comment = $"Feedback {i} on {session.Topic.ToLower()} session.",
                        SubmittedAt = DateTime.UtcNow.AddDays(-rnd.Next(30))
                    });
                }
            }

            context.Feedbacks.AddRange(feedbacks);
            context.SaveChanges();
        }
    }
}
