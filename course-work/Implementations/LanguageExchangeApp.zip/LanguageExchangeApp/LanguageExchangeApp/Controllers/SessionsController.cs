﻿using LanguageExchangeApp.Data;
using LanguageExchangeApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LanguageExchangeApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class SessionsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public SessionsController(ApplicationDbContext context) => _context = context;

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Session>>> GetAll([FromQuery] int? userId, [FromQuery] string? topic, [FromQuery] int page = 1, [FromQuery] int pageSize = 10)
        {
            var query = _context.Sessions.Include(s => s.User).Include(s => s.Partner).AsQueryable();

            if (userId.HasValue)
                query = query.Where(s => s.UserId == userId || s.PartnerId == userId);
            if (!string.IsNullOrEmpty(topic))
                query = query.Where(s => s.Topic.Contains(topic));

            var total = await query.CountAsync();
            var sessions = await query.Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();

            return Ok(new { total, sessions });
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Session>> Get(int id)
        {
            var session = await _context.Sessions.Include(s => s.User).Include(s => s.Partner).FirstOrDefaultAsync(s => s.Id == id);
            if (session == null) return NotFound();
            return Ok(session);
        }

        [HttpPost]
        public async Task<ActionResult<Session>> Create(Session session)
        {
            _context.Sessions.Add(session);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = session.Id }, session);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, Session session)
        {
            if (id != session.Id) return BadRequest();
            _context.Entry(session).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var session = await _context.Sessions.FindAsync(id);
            if (session == null) return NotFound();
            _context.Sessions.Remove(session);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
