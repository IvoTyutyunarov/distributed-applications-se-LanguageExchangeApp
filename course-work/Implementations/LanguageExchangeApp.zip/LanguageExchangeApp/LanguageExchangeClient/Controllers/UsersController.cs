﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Text;
using System.Net.Http.Headers;
using LanguageExchangeClient.Models;

namespace LanguageExchangeClient.Controllers
{
    public class UsersController : Controller
    {
        private readonly HttpClient _httpClient;

        public UsersController(HttpClient httpClient)
        {
            _httpClient = httpClient;
            _httpClient.BaseAddress = new Uri("https://localhost:5001/api/");
            // Ако имаш токен, го добави тук:
            // _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "YOUR_JWT_TOKEN");
        }

        // GET: Users
        public async Task<IActionResult> Index(string nativeLanguage, string languageToLearn, int page = 1, int pageSize = 10)
        {
            var url = $"users?nativeLanguage={nativeLanguage}&languageToLearn={languageToLearn}&page={page}&pageSize={pageSize}";
            var response = await _httpClient.GetAsync(url);
            if (!response.IsSuccessStatusCode) return View("Error");

            var jsonString = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            var result = JsonSerializer.Deserialize<UserListResponse>(jsonString, options);

            ViewBag.TotalUsers = result.Total;
            ViewBag.Page = page;
            ViewBag.PageSize = pageSize;

            return View(result.Users);
        }

        // GET: Users/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var response = await _httpClient.GetAsync($"users/{id}");
            if (!response.IsSuccessStatusCode) return NotFound();

            var user = await JsonSerializer.DeserializeAsync<User>(await response.Content.ReadAsStreamAsync());
            return View(user);
        }

        // GET: Users/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Users/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(User user)
        {
            if (!ModelState.IsValid) return View(user);

            var json = JsonSerializer.Serialize(user);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync("users", content);

            if (response.IsSuccessStatusCode) return RedirectToAction(nameof(Index));

            ModelState.AddModelError("", "Failed to create user");
            return View(user);
        }

        // GET: Users/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var response = await _httpClient.GetAsync($"users/{id}");
            if (!response.IsSuccessStatusCode) return NotFound();

            var user = await JsonSerializer.DeserializeAsync<User>(await response.Content.ReadAsStreamAsync());
            return View(user);
        }

        // POST: Users/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, User user)
        {
            if (id != user.Id) return BadRequest();

            if (!ModelState.IsValid) return View(user);

            var json = JsonSerializer.Serialize(user);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.PutAsync($"users/{id}", content);

            if (response.IsSuccessStatusCode) return RedirectToAction(nameof(Index));

            ModelState.AddModelError("", "Failed to update user");
            return View(user);
        }

        // GET: Users/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var response = await _httpClient.GetAsync($"users/{id}");
            if (!response.IsSuccessStatusCode) return NotFound();

            var user = await JsonSerializer.DeserializeAsync<User>(await response.Content.ReadAsStreamAsync());
            return View(user);
        }

        // POST: Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"users/{id}");
            if (response.IsSuccessStatusCode) return RedirectToAction(nameof(Index));

            ModelState.AddModelError("", "Failed to delete user");
            return RedirectToAction(nameof(Delete), new { id });
        }
    }

    // Допълнителен клас за сериализация на списъка с потребители + общ брой
    public class UserListResponse
    {
        public int Total { get; set; }
        public List<User> Users { get; set; }
    }
}
