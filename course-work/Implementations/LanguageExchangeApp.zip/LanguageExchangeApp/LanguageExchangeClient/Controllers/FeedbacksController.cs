﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Text;
using LanguageExchangeClient.Models;

namespace LanguageExchangeClient.Controllers
{
    public class FeedbacksController : Controller
    {
        private readonly HttpClient _httpClient;

        public FeedbacksController(HttpClient httpClient)
        {
            _httpClient = httpClient;
            _httpClient.BaseAddress = new Uri("https://localhost:5001/api/");
        }

        // GET: Feedbacks
        public async Task<IActionResult> Index()
        {
            var response = await _httpClient.GetAsync("feedbacks");
            if (!response.IsSuccessStatusCode) return View("Error");

            var jsonString = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            var feedbacks = JsonSerializer.Deserialize<List<Feedback>>(jsonString, options);

            return View(feedbacks);
        }

        // GET: Feedbacks/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var response = await _httpClient.GetAsync($"feedbacks/{id}");
            if (!response.IsSuccessStatusCode) return NotFound();

            var feedback = await JsonSerializer.DeserializeAsync<Feedback>(await response.Content.ReadAsStreamAsync());
            return View(feedback);
        }

        // GET: Feedbacks/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Feedbacks/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Feedback feedback)
        {
            if (!ModelState.IsValid) return View(feedback);

            var json = JsonSerializer.Serialize(feedback);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync("feedbacks", content);

            if (response.IsSuccessStatusCode) return RedirectToAction(nameof(Index));

            ModelState.AddModelError("", "Failed to create feedback");
            return View(feedback);
        }

        // GET: Feedbacks/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var response = await _httpClient.GetAsync($"feedbacks/{id}");
            if (!response.IsSuccessStatusCode) return NotFound();

            var feedback = await JsonSerializer.DeserializeAsync<Feedback>(await response.Content.ReadAsStreamAsync());
            return View(feedback);
        }

        // POST: Feedbacks/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Feedback feedback)
        {
            if (id != feedback.Id) return BadRequest();

            if (!ModelState.IsValid) return View(feedback);

            var json = JsonSerializer.Serialize(feedback);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.PutAsync($"feedbacks/{id}", content);

            if (response.IsSuccessStatusCode) return RedirectToAction(nameof(Index));

            ModelState.AddModelError("", "Failed to update feedback");
            return View(feedback);
        }

        // GET: Feedbacks/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var response = await _httpClient.GetAsync($"feedbacks/{id}");
            if (!response.IsSuccessStatusCode) return NotFound();

            var feedback = await JsonSerializer.DeserializeAsync<Feedback>(await response.Content.ReadAsStreamAsync());
            return View(feedback);
        }

        // POST: Feedbacks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"feedbacks/{id}");
            if (response.IsSuccessStatusCode) return RedirectToAction(nameof(Index));

            ModelState.AddModelError("", "Failed to delete feedback");
            return RedirectToAction(nameof(Delete), new { id });
        }
    }
}
