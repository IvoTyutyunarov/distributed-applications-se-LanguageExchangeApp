﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Text;
using LanguageExchangeClient.Models;

namespace LanguageExchangeClient.Controllers
{
    public class SessionsController : Controller
    {
        private readonly HttpClient _httpClient;

        public SessionsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
            _httpClient.BaseAddress = new Uri("https://localhost:5001/api/");
        }

        // GET: Sessions
        public async Task<IActionResult> Index(int? userId, string? topic, int page = 1, int pageSize = 10)
        {
            var url = $"sessions?userId={userId}&topic={topic}&page={page}&pageSize={pageSize}";
            var response = await _httpClient.GetAsync(url);
            if (!response.IsSuccessStatusCode) return View("Error");

            var jsonString = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            var result = JsonSerializer.Deserialize<SessionListResponse>(jsonString, options);

            ViewBag.TotalSessions = result.Total;
            ViewBag.Page = page;
            ViewBag.PageSize = pageSize;

            return View(result.Sessions);
        }

        // GET: Sessions/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var response = await _httpClient.GetAsync($"sessions/{id}");
            if (!response.IsSuccessStatusCode) return NotFound();

            var session = await JsonSerializer.DeserializeAsync<Session>(await response.Content.ReadAsStreamAsync());
            return View(session);
        }

        // GET: Sessions/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Sessions/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Session session)
        {
            if (!ModelState.IsValid) return View(session);

            var json = JsonSerializer.Serialize(session);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync("sessions", content);

            if (response.IsSuccessStatusCode) return RedirectToAction(nameof(Index));

            ModelState.AddModelError("", "Failed to create session");
            return View(session);
        }

        // GET: Sessions/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var response = await _httpClient.GetAsync($"sessions/{id}");
            if (!response.IsSuccessStatusCode) return NotFound();

            var session = await JsonSerializer.DeserializeAsync<Session>(await response.Content.ReadAsStreamAsync());
            return View(session);
        }

        // POST: Sessions/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Session session)
        {
            if (id != session.Id) return BadRequest();

            if (!ModelState.IsValid) return View(session);

            var json = JsonSerializer.Serialize(session);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.PutAsync($"sessions/{id}", content);

            if (response.IsSuccessStatusCode) return RedirectToAction(nameof(Index));

            ModelState.AddModelError("", "Failed to update session");
            return View(session);
        }

        // GET: Sessions/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var response = await _httpClient.GetAsync($"sessions/{id}");
            if (!response.IsSuccessStatusCode) return NotFound();

            var session = await JsonSerializer.DeserializeAsync<Session>(await response.Content.ReadAsStreamAsync());
            return View(session);
        }

        // POST: Sessions/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"sessions/{id}");
            if (response.IsSuccessStatusCode) return RedirectToAction(nameof(Index));

            ModelState.AddModelError("", "Failed to delete session");
            return RedirectToAction(nameof(Delete), new { id });
        }
    }

    public class SessionListResponse
    {
        public int Total { get; set; }
        public List<Session> Sessions { get; set; }
    }
}
