﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace LanguageExchangeClient.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string FullName { get; set; }

        [Required, EmailAddress, MaxLength(100)]
        public string Email { get; set; }

        public string? ProfileImagePath { get; set; }

        [Required, MaxLength(50)]
        public string NativeLanguage { get; set; }

        [Required, MaxLength(50)]
        public string LanguageToLearn { get; set; }

        [Required, MaxLength(50)]
        public string Password { get; set; }

        public DateTime CreatedAt { get; set; }
    }
}
