﻿using System.ComponentModel.DataAnnotations;

namespace LanguageExchangeClient.Models
{
    public class Feedback
    {
        public int Id { get; set; }

        [Required]
        public int SessionId { get; set; }

        [Required]
        [Range(1, 5)]
        public int Rating { get; set; }

        [MaxLength(500)]
        public string? Comment { get; set; }

        [Required]
        public DateTime SubmittedAt { get; set; }
    }

}
