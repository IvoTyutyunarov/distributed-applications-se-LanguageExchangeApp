﻿using System.ComponentModel.DataAnnotations;

namespace LanguageExchangeClient.Models
{
    public class Session
    {
        public int Id { get; set; }

        [Required]
        public int UserId { get; set; }

        [Required]
        public int PartnerId { get; set; }

        [Required]
        public DateTime ScheduledAt { get; set; }

        [MaxLength(200)]
        public string? Topic { get; set; }

        public int DurationMinutes { get; set; }
    }
}
