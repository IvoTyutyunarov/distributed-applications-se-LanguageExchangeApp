﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace LanguageExchangeClient.ViewModels
{
    public class SessionViewModel
    {
        public int Id { get; set; }

        [Required]
        public int UserId { get; set; }

        [Required]
        public int PartnerId { get; set; }

        [Required]
        public DateTime Date { get; set; }

        [MaxLength(200)]
        public string? Topic { get; set; }

        public int DurationMinutes { get; set; }

        public SelectList? Users { get; set; } // Dropdown за избор на потребители
    }
}
