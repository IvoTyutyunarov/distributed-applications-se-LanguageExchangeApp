﻿using System.ComponentModel.DataAnnotations;

namespace LanguageExchangeClient.ViewModels
{
    public class UserViewModel
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string FullName { get; set; }

        [Required, EmailAddress, MaxLength(100)]
        public string Email { get; set; }

        [Required, MaxLength(50)]
        public string NativeLanguage { get; set; }

        [Required, MaxLength(50)]
        public string LanguageToLearn { get; set; }

        [Required, MaxLength(50)]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        public IFormFile? ProfileImage { get; set; } // за качване на снимка

        public string? ExistingImagePath { get; set; }
    }
}
