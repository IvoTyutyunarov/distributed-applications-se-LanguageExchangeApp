﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace LanguageExchangeClient.ViewModels
{
    public class FeedbackViewModel
    {
        public int Id { get; set; }

        [Required]
        public int SessionId { get; set; }

        [Range(1, 5)]
        public int Rating { get; set; }

        [MaxLength(500)]
        public string? Comment { get; set; }

        public DateTime CreatedAt { get; set; }

        public SelectList? Sessions { get; set; } // За dropdown списък
    }
}
